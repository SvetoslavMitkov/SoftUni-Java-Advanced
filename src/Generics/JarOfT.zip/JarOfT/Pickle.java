package Generics.JarOfT;

public class Pickle {

}
